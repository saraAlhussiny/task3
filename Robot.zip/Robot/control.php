

<?php  
       session_start();
	   $db = mysqli_connect('localhost', 'root', '', 'control');

	   $movement = $_SESSION['m'];
	   
	   switch ($movement) {
  case 1:
    echo 'F' ;
    break;
  case 2:
    echo 'L' ;
    break;
  case 3:
    echo 'S' ;
    break;
  case 4:
    echo 'R' ;
    break;
  case 5:
    echo 'B' ;
    break;

}
	  ?>