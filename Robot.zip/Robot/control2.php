

<?php  
       session_start();
       $db = mysqli_connect('localhost', 'root', '', 'control');

	   $movement = $_GET['move'];
	   $_SESSION['m']= $_GET['move'];
	   
	   switch ($movement) {
  case 1:
    $query = "INSERT INTO task3 (Forwards) VALUES('F')";
    break;
  case 2:
    $query = "INSERT INTO task3 (Left1) VALUES('L')";
    break;
  case 3:
    $query = "INSERT INTO task3 (Stop) VALUES('S')";
    break;
  case 4:
    $query = "INSERT INTO task3 (Right1) VALUES('R')";
    break;
  case 5:
    $query = "INSERT INTO task3 (Backwards) VALUES('B')";
    break;

}
	 mysqli_query($db, $query);
	 
	 header('Location: control.html');
	  ?>